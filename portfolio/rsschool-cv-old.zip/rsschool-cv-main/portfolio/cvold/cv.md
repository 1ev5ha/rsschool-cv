# Vasilenko Alexey
## My contacts

- Git: Vargur31rus
- Mail: 31work@gmail.com or alexey31work@yandex.ru
- Tel: +7 (951) 130 1441
- Discord: Vargur#3952

## About me 
Industrial construction engineer. Web development was like a hobby. I want to change the order of things. Do what you like. Write code, create, think about UI / UX.
- PS. I used to create sites for friends using the constructors Tilda, Nethouse and was afraid to learn the code =)
---
## Skills
+ HTML 3/10
+ CSS 1/10
+ GitHub 3/10
+ PhotoShop 6/10
+ JS 1/10

## Legendary coder =]
```
class App {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```
---
## Experience
Freelance. Websites collected on constructors. Tilda, Nethouse.

## Education
- Belgorod Shukhov State Technological University (2001-2006)
- GeekBrains (some free courses)
- Netology (some free courses)

## English language - A2

