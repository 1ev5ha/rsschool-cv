Работы по этой CV остановленны, проект заерыт. =) <br>
CV на память. <br>
# Путь в тысячу миль начинается с первого шага

---

https://vargur31rus.github.io/rsschool-cv-old/cv

----

https://vargur31rus.github.io/rsschool-cv-old/

---
