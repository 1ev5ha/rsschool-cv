# Vasilenko Alexey
## My contacts

- Git: Vargur31rus
- Mail: 31work@gmail.com or alexey31work@yandex.ru
- Tel: +7 (910) 737 60 16 (MTS)
- Telegram: +79107376016
- Discord: Vargur#3952


## About me 

I have loved the IT industry since childhood. During my school years, I loved creating animations in Macromedia Dremweawer and writing in HTML.<br>
Adulthood has set priorities in its own way.<br>
The main priority is work in the specialty. In the field of industrial construction. Control engineer.<br>
Secondary direction: freelancing, web development on constructors (Tilda, Nethouse), SEO-optimization, advertising. For small and medium businesses.<br>
First, COVID changed the world, burnout at work, and after the military conflict affected my priorities...


Life is one and it is short. It's silly to keep putting things off until later.
---

## Skills

+ JavaScript 1/10
+ CSS 2/10
+ GIT 2/10
+ HTML 5/10
+ Figma 7/10
+ PhotoShop 7/10
+ UX/UI


## Legendary coder =]
```
class App {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```
---
## Work Experience
**Main stream**
* *Industrial engineering. As a Quality Engineer and negotiator* 

**Freelance**
* *Creation of websites on Tilda and Nethouse constructors +SEO*
* *Insisted Analytics (Yandex, Google) and advertising companies*
* *SMM*

## Education
* Html, CSS, - HTML Academy
* JavaScript, Html, CSS and other - RollingScopes 2021Q1
* Other Education platforms (EPAM, GeekBrains, Netology, Yandex, Stepik, Hexlet)

**2001-2006** Belgorod Shukhov State Technological University -
* Road and airfield construction engineer.


## English language - A2

## Hobbies
- Videogames (PC, PS)
- Desing 
- Music (Spotify member)
- Self-development
