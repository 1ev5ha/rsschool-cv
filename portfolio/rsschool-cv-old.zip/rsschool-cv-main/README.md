# rsschool-cv
Вместе с Роллинг Скоупс. 

https://vargur31rus.github.io/rsschool-cv/cv <br>
https://vargur31rus.github.io/rsschool-cv/
